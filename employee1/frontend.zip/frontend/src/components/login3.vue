<template>
    <div class="note">
    <el-main>
        <div class="login">
<!--          <div class="login-header">-->
<!--            <img class="login-he" src="../assets/index/login01.png" alt>-->
<!--          </div>-->
          <div class="form-box">
            <el-form
              :model="numberValidateForm"
              status-icon
              ref="numberValidateForm"
              class="demo-ruleForm"
            >
              <el-form-item
                prop="name"
                label="账号"
                :rules="[
            { required: false, message: '账号不能为空'},
          ]"
              >
                <el-input
                  type="text"
                  v-model.number="numberValidateForm.name"

                  placeholder="OA账户名"
                  class="text1"
                ></el-input>
              </el-form-item>
              <el-form-item
                prop="pass"
                label="密码"
                :rules="[
            { required: false, message: '密码不能为空'},
          ]"
              >
                <el-input
                  type="password"
                  v-model.number="numberValidateForm.pass"
                  autocomplete="off"
                  placeholder="密码"
                  class="text1"
                ></el-input>
              </el-form-item>
              <el-form-item class="addel">
<!--                <span @click="register">立即注册</span>-->
                <el-button type="text" @click="forgetpass">忘记密码?</el-button>

              </el-form-item>
              <el-form-item>
                <el-button
                  type="primary"
                  round
                  @click="submitForm('numberValidateForm')"
                  class="loginn"
                >立即登录</el-button>
              </el-form-item>
<!--              <el-form-item class="BAT-box">-->
<!--                <div class="qq-box"><img src="../assets/index/qq.png" alt=""></div>-->
<!--                <div class="qq-box"><img src="../assets/index/weixin.png" alt=""></div>-->
<!--                <div class="qq-box"><img src="../assets/index/weibo.png" alt=""></div>-->
<!--              </el-form-item>-->
            </el-form>
          </div>

        </div>
    </el-main>
   </div>
</template>
<script>
export default {
  data() {
    return {
      // note: {
      //   backgroundImage: "src(" + require("../assets/login/background.jpg") + ")",
      //   backgroundRepeat: "no-repeat",
      //   backgroundPosition: "center",
      // },
      numberValidateForm: {
        name: "",
        pass: ""
      }
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
            // let data = new FormData()
            // data.append('username',this.numberValidateForm.name)
            // data.append('password',this.numberValidateForm.pass)
            // this.$axios.post("api/login/",data).then((res)=>{
            this.$axios.post("api/login/",{
              username: this.numberValidateForm.name,
              password: this.numberValidateForm.pass
            }).then((res)=>{
                switch(res.data.first_name){
                  case "11": this.$router.push({name:"assess"});
                       break;
                  case "22": this.$router.push({name:"attence"});
                       break;
                  case "33": this.$router.push({name:"ceomark"});
                       break;
                  case "44": this.$router.push({name:"managermark"});
                       break;
                  case "55": this.$router.push({name:"others"});
                       break;
                  case "66": this.$router.push({name:"download"});
                       break;
              // console.log(12345678)
              // this.$router.push({name:"managermark"})
            }
          })
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    forgetpass(){
      this.$alert('请联系系统中心管理员', '提示', {
          confirmButtonText: '确定',
          callback: action => {
            this.$message({
              type: 'info',
              message: `请尽快联系`
            });
          }
        });
    },
    register(){
      this.$router.push({ name: "register" });
    }
  },

};
</script>



<style scoped>
body {
  margin: 0;
  padding: 0;
}
.note {
  position: relative;
}
.form-box{
    margin-top: 40%;
    margin-left: 10%;

}
.loginn{
    width:100%;
    letter-spacing: 2px;
}
@media screen and (min-width:768px){


.note {
  position: relative;
  width:100%;
  height:100%;
  background-repeat: no-repeat;
  background-image:url('../../src/assets/background.jpg');
  background-size: 100% 100%;
}

.el-main  {
  width: 100%;
  min-height:100vh;
  position: relative;
  /*box-sizing: border-box;*/
  /*height: 751px;*/
}

.login {
  width: 377px;
  height: 450px;
  background: #ffffff;
  box-shadow: 4px 3px 16px 0px#cacaca;
  position: absolute;
  /* position: relative; */
  top: 18%;
  right: 2%;
}
.form-box {
  width: 282px;
  height: 324px;
  margin-top: 14%;
  margin-left: 13%;
  /* margin: auto;
  margin-top: 53px;  */
  /*box-sizing: border-box;*/
  overflow: hidden;
}

.loginn{
  width: 100%;
  /* margin:20% 10% 10%; */
  /* background-color: #7d7d7d;
	box-shadow: 0px 3px 5px 0px
	rgba(195, 195, 195, 0.74);
  color: #ffffff;
	opacity: 0.8;
  letter-spacing: 2px;
  border: none; */
}
}
/*立即登陆按钮的样式*/

</style>
